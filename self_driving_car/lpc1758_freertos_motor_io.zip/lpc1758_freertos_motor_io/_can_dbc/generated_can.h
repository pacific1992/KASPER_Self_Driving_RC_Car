/// DBC file: ../../lpc1758_freertos/_can_dbc/243.dbc    Self node: 'MOTORIO'  (ALL = 0)
/// This file can be included by a source file, for example: #include "generated.h"
#ifndef __GENEARTED_DBC_PARSER
#define __GENERATED_DBC_PARSER
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>



/// Extern function needed for dbc_encode_and_send()
extern bool dbc_app_send_can_msg(uint32_t mid, uint8_t dlc, uint8_t bytes[8]);

/// Missing in Action structure
typedef struct {
    uint32_t is_mia : 1;          ///< Missing in action flag
    uint32_t mia_counter_ms : 31; ///< Missing in action counter
} dbc_mia_info_t;

/// CAN message header structure
typedef struct { 
    uint32_t mid; ///< Message ID of the message
    uint8_t  dlc; ///< Data length of the message
} dbc_msg_hdr_t; 

static const dbc_msg_hdr_t STOP_CAR_HDR =                         {  100, 1 };
static const dbc_msg_hdr_t RESET_HDR =                            {  110, 1 };
static const dbc_msg_hdr_t POWER_SYNC_ACK_HDR =                   {  120, 1 };
// static const dbc_msg_hdr_t STOP_CMD_APP_HDR =                     {  130, 1 };
// static const dbc_msg_hdr_t START_CMD_APP_HDR =                    {  140, 1 };
static const dbc_msg_hdr_t DESTINATION_REACHED_HDR =              {  150, 1 };
static const dbc_msg_hdr_t MOTOR_POWER_SYNC_HDR =                 {  200, 1 };
// static const dbc_msg_hdr_t SENSOR_POWER_SYNC_HDR =                {  210, 1 };
// static const dbc_msg_hdr_t BRIDGE_POWER_SYNC_HDR =                {  220, 1 };
// static const dbc_msg_hdr_t GEO_POWER_SYNC_HDR =                   {  230, 1 };
static const dbc_msg_hdr_t SENSOR_SONIC_HDR =                     {  400, 8 };
static const dbc_msg_hdr_t MOTORIO_DIRECTION_HDR =                {  410, 3 };
static const dbc_msg_hdr_t BRIDGE_TOTAL_CHECKPOINT_HDR =          {  420, 1 };
// static const dbc_msg_hdr_t RECEIVE_START_ACK_HDR =                {  430, 1 };
// static const dbc_msg_hdr_t BLUETOOTH_DATA_HDR =                   {  440, 8 };
// static const dbc_msg_hdr_t NEXT_CHECKPOINT_DATA_HDR =             {  450, 8 };
static const dbc_msg_hdr_t COMPASS_DATA_HDR =                     {  460, 7 };
// static const dbc_msg_hdr_t CURRENT_LOCATION_ACK_HDR =             {  470, 1 };
static const dbc_msg_hdr_t GPS_LOCATION_HDR =                     {  480, 8 };
// static const dbc_msg_hdr_t BATTERY_STATUS_HDR =                   {  500, 1 };




/// Message: STOP_CAR from 'MASTER', DLC: 1 byte(s), MID: 100
typedef struct {
    uint8_t STOP_CAR_data;                    ///< B7:0   Destination: BRIDGE,GEO,SENSOR,MOTORIO

    dbc_mia_info_t mia_info;
} STOP_CAR_t;


/// Message: RESET from 'MASTER', DLC: 1 byte(s), MID: 110
typedef struct {
    uint8_t RESET_data;                       ///< B7:0   Destination: BRIDGE,GEO,SENSOR,MOTORIO

    dbc_mia_info_t mia_info;
} RESET_t;


/// Message: POWER_SYNC_ACK from 'MASTER', DLC: 1 byte(s), MID: 120
typedef struct {
    uint8_t POWER_SYNC_ACK_data;              ///< B7:0   Destination: BRIDGE,GEO,SENSOR,MOTORIO

    dbc_mia_info_t mia_info;
} POWER_SYNC_ACK_t;


/// Message: DESTINATION_REACHED from 'MASTER', DLC: 1 byte(s), MID: 150
typedef struct {
    uint8_t DESTINATION_REACHED_ack;          ///< B7:0   Destination: MOTORIO

    dbc_mia_info_t mia_info;
} DESTINATION_REACHED_t;


/// Message: MOTOR_POWER_SYNC from 'MOTORIO', DLC: 1 byte(s), MID: 200
typedef struct {
    uint8_t MOTOR_POWER_SYNC_data;            ///< B7:0   Destination: MASTER

    // No dbc_mia_info_t for a message that we will send
} MOTOR_POWER_SYNC_t;


/// Message: SENSOR_SONIC from 'SENSOR', DLC: 8 byte(s), MID: 400
typedef struct {
    uint16_t SENSORS_SONIC_front_left;        ///< B15:0   Destination: MASTER,MOTORIO
    uint16_t SENSORS_SONIC_front_right;       ///< B31:16   Destination: MASTER,MOTORIO
    uint16_t SENSORS_SONIC_front_center;      ///< B47:32   Destination: MASTER,MOTORIO
    uint16_t SENSORS_SONIC_back;              ///< B63:48   Destination: MASTER,MOTORIO

    dbc_mia_info_t mia_info;
} SENSOR_SONIC_t;


/// Message: MOTORIO_DIRECTION from 'MASTER', DLC: 3 byte(s), MID: 410
typedef struct {
    uint8_t MOTORIO_DIRECTION_speed;          ///< B7:0  Min: 0 Max: 10   Destination: MOTORIO
    int8_t MOTORIO_DIRECTION_turn;            ///< B15:8  Min: -3 Max: 3   Destination: MOTORIO
    uint8_t MOTORIO_DIRECTION_direction;      ///< B23:16  Min: 0 Max: 2   Destination: MOTORIO

    dbc_mia_info_t mia_info;
} MOTORIO_DIRECTION_t;


/// Message: BRIDGE_TOTAL_CHECKPOINT from 'BRIDGE', DLC: 1 byte(s), MID: 420
typedef struct {
    uint8_t BRIDGE_TOTAL_CHECKPOINT_NUMBER;   ///< B7:0   Destination: MASTER,MOTORIO

    dbc_mia_info_t mia_info;
} BRIDGE_TOTAL_CHECKPOINT_t;


/// Message: COMPASS_DATA from 'GEO', DLC: 7 byte(s), MID: 460
typedef struct {
    uint8_t COMPASS_DATA_speed;               ///< B7:0   Destination: MASTER,MOTORIO
    float COMPASS_DATA_heading;               ///< B23:8   Destination: MASTER,MOTORIO
    float COMPASS_DATA_bearing;               ///< B39:24   Destination: MASTER,MOTORIO
    float COMPASS_DATA_distance;              ///< B55:40   Destination: MASTER,MOTORIO

    dbc_mia_info_t mia_info;
} COMPASS_DATA_t;


/// Message: GPS_LOCATION from 'GEO', DLC: 8 byte(s), MID: 480
typedef struct {
    float GPS_LOCATION_latitude;              ///< B31:0   Destination: MASTER,BRIDGE,MOTORIO
    float GPS_LOCATION_longitude;             ///< B63:32   Destination: MASTER,BRIDGE,MOTORIO

    dbc_mia_info_t mia_info;
} GPS_LOCATION_t;


/// @{ These 'externs' need to be defined in a source file of your project
extern const uint32_t                             STOP_CAR__MIA_MS;
extern const STOP_CAR_t                           STOP_CAR__MIA_MSG;
extern const uint32_t                             RESET__MIA_MS;
extern const RESET_t                              RESET__MIA_MSG;
extern const uint32_t                             POWER_SYNC_ACK__MIA_MS;
extern const POWER_SYNC_ACK_t                     POWER_SYNC_ACK__MIA_MSG;
extern const uint32_t                             DESTINATION_REACHED__MIA_MS;
extern const DESTINATION_REACHED_t                DESTINATION_REACHED__MIA_MSG;
extern const uint32_t                             SENSOR_SONIC__MIA_MS;
extern const SENSOR_SONIC_t                       SENSOR_SONIC__MIA_MSG;
extern const uint32_t                             MOTORIO_DIRECTION__MIA_MS;
extern const MOTORIO_DIRECTION_t                  MOTORIO_DIRECTION__MIA_MSG;
extern const uint32_t                             BRIDGE_TOTAL_CHECKPOINT__MIA_MS;
extern const BRIDGE_TOTAL_CHECKPOINT_t            BRIDGE_TOTAL_CHECKPOINT__MIA_MSG;
extern const uint32_t                             COMPASS_DATA__MIA_MS;
extern const COMPASS_DATA_t                       COMPASS_DATA__MIA_MSG;
extern const uint32_t                             GPS_LOCATION__MIA_MS;
extern const GPS_LOCATION_t                       GPS_LOCATION__MIA_MSG;
/// @}


/// Not generating code for dbc_encode_STOP_CAR() since the sender is MASTER and we are MOTORIO

/// Not generating code for dbc_encode_RESET() since the sender is MASTER and we are MOTORIO

/// Not generating code for dbc_encode_POWER_SYNC_ACK() since the sender is MASTER and we are MOTORIO

/// Not generating code for dbc_encode_STOP_CMD_APP() since the sender is BRIDGE and we are MOTORIO

/// Not generating code for dbc_encode_START_CMD_APP() since the sender is BRIDGE and we are MOTORIO

/// Not generating code for dbc_encode_DESTINATION_REACHED() since the sender is MASTER and we are MOTORIO

/// Encode MOTORIO's 'MOTOR_POWER_SYNC' message
/// @returns the message header of this message
static inline dbc_msg_hdr_t dbc_encode_MOTOR_POWER_SYNC(uint8_t bytes[8], MOTOR_POWER_SYNC_t *from)
{
    uint32_t raw;
    bytes[0]=bytes[1]=bytes[2]=bytes[3]=bytes[4]=bytes[5]=bytes[6]=bytes[7]=0;

    raw = ((uint32_t)(((from->MOTOR_POWER_SYNC_data)))) & 0xff;
    bytes[0] |= (((uint8_t)(raw) & 0xff)); ///< 8 bit(s) starting from B0

    return MOTOR_POWER_SYNC_HDR;
}

/// Encode and send for dbc_encode_MOTOR_POWER_SYNC() message
static inline bool dbc_encode_and_send_MOTOR_POWER_SYNC(MOTOR_POWER_SYNC_t *from)
{
    uint8_t bytes[8];
    const dbc_msg_hdr_t hdr = dbc_encode_MOTOR_POWER_SYNC(bytes, from);
    return dbc_app_send_can_msg(hdr.mid, hdr.dlc, bytes);
}



/// Not generating code for dbc_encode_SENSOR_POWER_SYNC() since the sender is SENSOR and we are MOTORIO

/// Not generating code for dbc_encode_BRIDGE_POWER_SYNC() since the sender is BRIDGE and we are MOTORIO

/// Not generating code for dbc_encode_GEO_POWER_SYNC() since the sender is GEO and we are MOTORIO

/// Not generating code for dbc_encode_SENSOR_SONIC() since the sender is SENSOR and we are MOTORIO

/// Not generating code for dbc_encode_MOTORIO_DIRECTION() since the sender is MASTER and we are MOTORIO

/// Not generating code for dbc_encode_BRIDGE_TOTAL_CHECKPOINT() since the sender is BRIDGE and we are MOTORIO

/// Not generating code for dbc_encode_RECEIVE_START_ACK() since the sender is MASTER and we are MOTORIO

/// Not generating code for dbc_encode_BLUETOOTH_DATA() since the sender is BRIDGE and we are MOTORIO

/// Not generating code for dbc_encode_NEXT_CHECKPOINT_DATA() since the sender is MASTER and we are MOTORIO

/// Not generating code for dbc_encode_COMPASS_DATA() since the sender is GEO and we are MOTORIO

/// Not generating code for dbc_encode_CURRENT_LOCATION_ACK() since the sender is BRIDGE and we are MOTORIO

/// Not generating code for dbc_encode_GPS_LOCATION() since the sender is GEO and we are MOTORIO

/// Not generating code for dbc_encode_BATTERY_STATUS() since the sender is SENSOR and we are MOTORIO

/// Decode MASTER's 'STOP_CAR' message
/// @param hdr  The header of the message to validate its DLC and MID; this can be NULL to skip this check
static inline bool dbc_decode_STOP_CAR(STOP_CAR_t *to, const uint8_t bytes[8], const dbc_msg_hdr_t *hdr)
{
    const bool success = true;
    // If msg header is provided, check if the DLC and the MID match
    if (NULL != hdr && (hdr->dlc != STOP_CAR_HDR.dlc || hdr->mid != STOP_CAR_HDR.mid)) {
        return !success;
    }

    uint32_t raw;
    raw  = ((uint32_t)((bytes[0]))); ///< 8 bit(s) from B0
    to->STOP_CAR_data = ((raw));

    to->mia_info.mia_counter_ms = 0; ///< Reset the MIA counter

    return success;
}


/// Decode MASTER's 'RESET' message
/// @param hdr  The header of the message to validate its DLC and MID; this can be NULL to skip this check
static inline bool dbc_decode_RESET(RESET_t *to, const uint8_t bytes[8], const dbc_msg_hdr_t *hdr)
{
    const bool success = true;
    // If msg header is provided, check if the DLC and the MID match
    if (NULL != hdr && (hdr->dlc != RESET_HDR.dlc || hdr->mid != RESET_HDR.mid)) {
        return !success;
    }

    uint32_t raw;
    raw  = ((uint32_t)((bytes[0]))); ///< 8 bit(s) from B0
    to->RESET_data = ((raw));

    to->mia_info.mia_counter_ms = 0; ///< Reset the MIA counter

    return success;
}


/// Decode MASTER's 'POWER_SYNC_ACK' message
/// @param hdr  The header of the message to validate its DLC and MID; this can be NULL to skip this check
static inline bool dbc_decode_POWER_SYNC_ACK(POWER_SYNC_ACK_t *to, const uint8_t bytes[8], const dbc_msg_hdr_t *hdr)
{
    const bool success = true;
    // If msg header is provided, check if the DLC and the MID match
    if (NULL != hdr && (hdr->dlc != POWER_SYNC_ACK_HDR.dlc || hdr->mid != POWER_SYNC_ACK_HDR.mid)) {
        return !success;
    }

    uint32_t raw;
    raw  = ((uint32_t)((bytes[0]))); ///< 8 bit(s) from B0
    to->POWER_SYNC_ACK_data = ((raw));

    to->mia_info.mia_counter_ms = 0; ///< Reset the MIA counter

    return success;
}


/// Not generating code for dbc_decode_STOP_CMD_APP() since 'MOTORIO' is not the recipient of any of the signals

/// Not generating code for dbc_decode_START_CMD_APP() since 'MOTORIO' is not the recipient of any of the signals

/// Decode MASTER's 'DESTINATION_REACHED' message
/// @param hdr  The header of the message to validate its DLC and MID; this can be NULL to skip this check
static inline bool dbc_decode_DESTINATION_REACHED(DESTINATION_REACHED_t *to, const uint8_t bytes[8], const dbc_msg_hdr_t *hdr)
{
    const bool success = true;
    // If msg header is provided, check if the DLC and the MID match
    if (NULL != hdr && (hdr->dlc != DESTINATION_REACHED_HDR.dlc || hdr->mid != DESTINATION_REACHED_HDR.mid)) {
        return !success;
    }

    uint32_t raw;
    raw  = ((uint32_t)((bytes[0]))); ///< 8 bit(s) from B0
    to->DESTINATION_REACHED_ack = ((raw));

    to->mia_info.mia_counter_ms = 0; ///< Reset the MIA counter

    return success;
}


/// Not generating code for dbc_decode_MOTOR_POWER_SYNC() since 'MOTORIO' is not the recipient of any of the signals

/// Not generating code for dbc_decode_SENSOR_POWER_SYNC() since 'MOTORIO' is not the recipient of any of the signals

/// Not generating code for dbc_decode_BRIDGE_POWER_SYNC() since 'MOTORIO' is not the recipient of any of the signals

/// Not generating code for dbc_decode_GEO_POWER_SYNC() since 'MOTORIO' is not the recipient of any of the signals

/// Decode SENSOR's 'SENSOR_SONIC' message
/// @param hdr  The header of the message to validate its DLC and MID; this can be NULL to skip this check
static inline bool dbc_decode_SENSOR_SONIC(SENSOR_SONIC_t *to, const uint8_t bytes[8], const dbc_msg_hdr_t *hdr)
{
    const bool success = true;
    // If msg header is provided, check if the DLC and the MID match
    if (NULL != hdr && (hdr->dlc != SENSOR_SONIC_HDR.dlc || hdr->mid != SENSOR_SONIC_HDR.mid)) {
        return !success;
    }

    uint32_t raw;
    raw  = ((uint32_t)((bytes[0]))); ///< 8 bit(s) from B0
    raw |= ((uint32_t)((bytes[1]))) << 8; ///< 8 bit(s) from B8
    to->SENSORS_SONIC_front_left = ((raw));
    raw  = ((uint32_t)((bytes[2]))); ///< 8 bit(s) from B16
    raw |= ((uint32_t)((bytes[3]))) << 8; ///< 8 bit(s) from B24
    to->SENSORS_SONIC_front_right = ((raw));
    raw  = ((uint32_t)((bytes[4]))); ///< 8 bit(s) from B32
    raw |= ((uint32_t)((bytes[5]))) << 8; ///< 8 bit(s) from B40
    to->SENSORS_SONIC_front_center = ((raw));
    raw  = ((uint32_t)((bytes[6]))); ///< 8 bit(s) from B48
    raw |= ((uint32_t)((bytes[7]))) << 8; ///< 8 bit(s) from B56
    to->SENSORS_SONIC_back = ((raw));

    to->mia_info.mia_counter_ms = 0; ///< Reset the MIA counter

    return success;
}


/// Decode MASTER's 'MOTORIO_DIRECTION' message
/// @param hdr  The header of the message to validate its DLC and MID; this can be NULL to skip this check
static inline bool dbc_decode_MOTORIO_DIRECTION(MOTORIO_DIRECTION_t *to, const uint8_t bytes[8], const dbc_msg_hdr_t *hdr)
{
    const bool success = true;
    // If msg header is provided, check if the DLC and the MID match
    if (NULL != hdr && (hdr->dlc != MOTORIO_DIRECTION_HDR.dlc || hdr->mid != MOTORIO_DIRECTION_HDR.mid)) {
        return !success;
    }

    uint32_t raw;
    raw  = ((uint32_t)((bytes[0]))); ///< 8 bit(s) from B0
    to->MOTORIO_DIRECTION_speed = ((raw));
    raw  = ((uint32_t)((bytes[1]))); ///< 8 bit(s) from B8
    to->MOTORIO_DIRECTION_turn = ((raw) + (-4));
    raw  = ((uint32_t)((bytes[2]))); ///< 8 bit(s) from B16
    to->MOTORIO_DIRECTION_direction = ((raw));

    to->mia_info.mia_counter_ms = 0; ///< Reset the MIA counter

    return success;
}


/// Decode BRIDGE's 'BRIDGE_TOTAL_CHECKPOINT' message
/// @param hdr  The header of the message to validate its DLC and MID; this can be NULL to skip this check
static inline bool dbc_decode_BRIDGE_TOTAL_CHECKPOINT(BRIDGE_TOTAL_CHECKPOINT_t *to, const uint8_t bytes[8], const dbc_msg_hdr_t *hdr)
{
    const bool success = true;
    // If msg header is provided, check if the DLC and the MID match
    if (NULL != hdr && (hdr->dlc != BRIDGE_TOTAL_CHECKPOINT_HDR.dlc || hdr->mid != BRIDGE_TOTAL_CHECKPOINT_HDR.mid)) {
        return !success;
    }

    uint32_t raw;
    raw  = ((uint32_t)((bytes[0]))); ///< 8 bit(s) from B0
    to->BRIDGE_TOTAL_CHECKPOINT_NUMBER = ((raw));

    to->mia_info.mia_counter_ms = 0; ///< Reset the MIA counter

    return success;
}


/// Not generating code for dbc_decode_RECEIVE_START_ACK() since 'MOTORIO' is not the recipient of any of the signals

/// Not generating code for dbc_decode_BLUETOOTH_DATA() since 'MOTORIO' is not the recipient of any of the signals

/// Not generating code for dbc_decode_NEXT_CHECKPOINT_DATA() since 'MOTORIO' is not the recipient of any of the signals

/// Decode GEO's 'COMPASS_DATA' message
/// @param hdr  The header of the message to validate its DLC and MID; this can be NULL to skip this check
static inline bool dbc_decode_COMPASS_DATA(COMPASS_DATA_t *to, const uint8_t bytes[8], const dbc_msg_hdr_t *hdr)
{
    const bool success = true;
    // If msg header is provided, check if the DLC and the MID match
    if (NULL != hdr && (hdr->dlc != COMPASS_DATA_HDR.dlc || hdr->mid != COMPASS_DATA_HDR.mid)) {
        return !success;
    }

    uint32_t raw;
    raw  = ((uint32_t)((bytes[0]))); ///< 8 bit(s) from B0
    to->COMPASS_DATA_speed = ((raw));
    raw  = ((uint32_t)((bytes[1]))); ///< 8 bit(s) from B8
    raw |= ((uint32_t)((bytes[2]))) << 8; ///< 8 bit(s) from B16
    to->COMPASS_DATA_heading = ((raw * 0.01));
    raw  = ((uint32_t)((bytes[3]))); ///< 8 bit(s) from B24
    raw |= ((uint32_t)((bytes[4]))) << 8; ///< 8 bit(s) from B32
    to->COMPASS_DATA_bearing = ((raw * 0.01));
    raw  = ((uint32_t)((bytes[5]))); ///< 8 bit(s) from B40
    raw |= ((uint32_t)((bytes[6]))) << 8; ///< 8 bit(s) from B48
    to->COMPASS_DATA_distance = ((raw * 0.01));

    to->mia_info.mia_counter_ms = 0; ///< Reset the MIA counter

    return success;
}


/// Not generating code for dbc_decode_CURRENT_LOCATION_ACK() since 'MOTORIO' is not the recipient of any of the signals

/// Decode GEO's 'GPS_LOCATION' message
/// @param hdr  The header of the message to validate its DLC and MID; this can be NULL to skip this check
static inline bool dbc_decode_GPS_LOCATION(GPS_LOCATION_t *to, const uint8_t bytes[8], const dbc_msg_hdr_t *hdr)
{
    const bool success = true;
    // If msg header is provided, check if the DLC and the MID match
    if (NULL != hdr && (hdr->dlc != GPS_LOCATION_HDR.dlc || hdr->mid != GPS_LOCATION_HDR.mid)) {
        return !success;
    }

    uint32_t raw;
    raw  = ((uint32_t)((bytes[0]))); ///< 8 bit(s) from B0
    raw |= ((uint32_t)((bytes[1]))) << 8; ///< 8 bit(s) from B8
    raw |= ((uint32_t)((bytes[2]))) << 16; ///< 8 bit(s) from B16
    raw |= ((uint32_t)((bytes[3]))) << 24; ///< 8 bit(s) from B24
    to->GPS_LOCATION_latitude = ((raw * 1e-06));
    raw  = ((uint32_t)((bytes[4]))); ///< 8 bit(s) from B32
    raw |= ((uint32_t)((bytes[5]))) << 8; ///< 8 bit(s) from B40
    raw |= ((uint32_t)((bytes[6]))) << 16; ///< 8 bit(s) from B48
    raw |= ((uint32_t)((bytes[7]))) << 24; ///< 8 bit(s) from B56
    to->GPS_LOCATION_longitude = ((raw * 1e-06) + (-127));

    to->mia_info.mia_counter_ms = 0; ///< Reset the MIA counter

    return success;
}


/// Not generating code for dbc_decode_BATTERY_STATUS() since 'MOTORIO' is not the recipient of any of the signals

/// Handle the MIA for MASTER's STOP_CAR message
/// @param   time_incr_ms  The time to increment the MIA counter with
/// @returns true if the MIA just occurred
/// @post    If the MIA counter reaches the MIA threshold, MIA struct will be copied to *msg
static inline bool dbc_handle_mia_STOP_CAR(STOP_CAR_t *msg, uint32_t time_incr_ms)
{
    bool mia_occurred = false;
    const dbc_mia_info_t old_mia = msg->mia_info;
    msg->mia_info.is_mia = (msg->mia_info.mia_counter_ms >= STOP_CAR__MIA_MS);

    if (!msg->mia_info.is_mia) { // Not MIA yet, so keep incrementing the MIA counter
        msg->mia_info.mia_counter_ms += time_incr_ms;
    }
    else if(!old_mia.is_mia)   { // Previously not MIA, but it is MIA now
        // Copy MIA struct, then re-write the MIA counter and is_mia that is overwriten
        *msg = STOP_CAR__MIA_MSG;
        msg->mia_info.mia_counter_ms = STOP_CAR__MIA_MS;
        msg->mia_info.is_mia = true;
        mia_occurred = true;
    }

    return mia_occurred;
}

/// Handle the MIA for MASTER's RESET message
/// @param   time_incr_ms  The time to increment the MIA counter with
/// @returns true if the MIA just occurred
/// @post    If the MIA counter reaches the MIA threshold, MIA struct will be copied to *msg
static inline bool dbc_handle_mia_RESET(RESET_t *msg, uint32_t time_incr_ms)
{
    bool mia_occurred = false;
    const dbc_mia_info_t old_mia = msg->mia_info;
    msg->mia_info.is_mia = (msg->mia_info.mia_counter_ms >= RESET__MIA_MS);

    if (!msg->mia_info.is_mia) { // Not MIA yet, so keep incrementing the MIA counter
        msg->mia_info.mia_counter_ms += time_incr_ms;
    }
    else if(!old_mia.is_mia)   { // Previously not MIA, but it is MIA now
        // Copy MIA struct, then re-write the MIA counter and is_mia that is overwriten
        *msg = RESET__MIA_MSG;
        msg->mia_info.mia_counter_ms = RESET__MIA_MS;
        msg->mia_info.is_mia = true;
        mia_occurred = true;
    }

    return mia_occurred;
}

/// Handle the MIA for MASTER's POWER_SYNC_ACK message
/// @param   time_incr_ms  The time to increment the MIA counter with
/// @returns true if the MIA just occurred
/// @post    If the MIA counter reaches the MIA threshold, MIA struct will be copied to *msg
static inline bool dbc_handle_mia_POWER_SYNC_ACK(POWER_SYNC_ACK_t *msg, uint32_t time_incr_ms)
{
    bool mia_occurred = false;
    const dbc_mia_info_t old_mia = msg->mia_info;
    msg->mia_info.is_mia = (msg->mia_info.mia_counter_ms >= POWER_SYNC_ACK__MIA_MS);

    if (!msg->mia_info.is_mia) { // Not MIA yet, so keep incrementing the MIA counter
        msg->mia_info.mia_counter_ms += time_incr_ms;
    }
    else if(!old_mia.is_mia)   { // Previously not MIA, but it is MIA now
        // Copy MIA struct, then re-write the MIA counter and is_mia that is overwriten
        *msg = POWER_SYNC_ACK__MIA_MSG;
        msg->mia_info.mia_counter_ms = POWER_SYNC_ACK__MIA_MS;
        msg->mia_info.is_mia = true;
        mia_occurred = true;
    }

    return mia_occurred;
}

/// Handle the MIA for MASTER's DESTINATION_REACHED message
/// @param   time_incr_ms  The time to increment the MIA counter with
/// @returns true if the MIA just occurred
/// @post    If the MIA counter reaches the MIA threshold, MIA struct will be copied to *msg
static inline bool dbc_handle_mia_DESTINATION_REACHED(DESTINATION_REACHED_t *msg, uint32_t time_incr_ms)
{
    bool mia_occurred = false;
    const dbc_mia_info_t old_mia = msg->mia_info;
    msg->mia_info.is_mia = (msg->mia_info.mia_counter_ms >= DESTINATION_REACHED__MIA_MS);

    if (!msg->mia_info.is_mia) { // Not MIA yet, so keep incrementing the MIA counter
        msg->mia_info.mia_counter_ms += time_incr_ms;
    }
    else if(!old_mia.is_mia)   { // Previously not MIA, but it is MIA now
        // Copy MIA struct, then re-write the MIA counter and is_mia that is overwriten
        *msg = DESTINATION_REACHED__MIA_MSG;
        msg->mia_info.mia_counter_ms = DESTINATION_REACHED__MIA_MS;
        msg->mia_info.is_mia = true;
        mia_occurred = true;
    }

    return mia_occurred;
}

/// Handle the MIA for SENSOR's SENSOR_SONIC message
/// @param   time_incr_ms  The time to increment the MIA counter with
/// @returns true if the MIA just occurred
/// @post    If the MIA counter reaches the MIA threshold, MIA struct will be copied to *msg
static inline bool dbc_handle_mia_SENSOR_SONIC(SENSOR_SONIC_t *msg, uint32_t time_incr_ms)
{
    bool mia_occurred = false;
    const dbc_mia_info_t old_mia = msg->mia_info;
    msg->mia_info.is_mia = (msg->mia_info.mia_counter_ms >= SENSOR_SONIC__MIA_MS);

    if (!msg->mia_info.is_mia) { // Not MIA yet, so keep incrementing the MIA counter
        msg->mia_info.mia_counter_ms += time_incr_ms;
    }
    else if(!old_mia.is_mia)   { // Previously not MIA, but it is MIA now
        // Copy MIA struct, then re-write the MIA counter and is_mia that is overwriten
        *msg = SENSOR_SONIC__MIA_MSG;
        msg->mia_info.mia_counter_ms = SENSOR_SONIC__MIA_MS;
        msg->mia_info.is_mia = true;
        mia_occurred = true;
    }

    return mia_occurred;
}

/// Handle the MIA for MASTER's MOTORIO_DIRECTION message
/// @param   time_incr_ms  The time to increment the MIA counter with
/// @returns true if the MIA just occurred
/// @post    If the MIA counter reaches the MIA threshold, MIA struct will be copied to *msg
static inline bool dbc_handle_mia_MOTORIO_DIRECTION(MOTORIO_DIRECTION_t *msg, uint32_t time_incr_ms)
{
    bool mia_occurred = false;
    const dbc_mia_info_t old_mia = msg->mia_info;
    msg->mia_info.is_mia = (msg->mia_info.mia_counter_ms >= MOTORIO_DIRECTION__MIA_MS);

    if (!msg->mia_info.is_mia) { // Not MIA yet, so keep incrementing the MIA counter
        msg->mia_info.mia_counter_ms += time_incr_ms;
    }
    else if(!old_mia.is_mia)   { // Previously not MIA, but it is MIA now
        // Copy MIA struct, then re-write the MIA counter and is_mia that is overwriten
        *msg = MOTORIO_DIRECTION__MIA_MSG;
        msg->mia_info.mia_counter_ms = MOTORIO_DIRECTION__MIA_MS;
        msg->mia_info.is_mia = true;
        mia_occurred = true;
    }

    return mia_occurred;
}

/// Handle the MIA for BRIDGE's BRIDGE_TOTAL_CHECKPOINT message
/// @param   time_incr_ms  The time to increment the MIA counter with
/// @returns true if the MIA just occurred
/// @post    If the MIA counter reaches the MIA threshold, MIA struct will be copied to *msg
static inline bool dbc_handle_mia_BRIDGE_TOTAL_CHECKPOINT(BRIDGE_TOTAL_CHECKPOINT_t *msg, uint32_t time_incr_ms)
{
    bool mia_occurred = false;
    const dbc_mia_info_t old_mia = msg->mia_info;
    msg->mia_info.is_mia = (msg->mia_info.mia_counter_ms >= BRIDGE_TOTAL_CHECKPOINT__MIA_MS);

    if (!msg->mia_info.is_mia) { // Not MIA yet, so keep incrementing the MIA counter
        msg->mia_info.mia_counter_ms += time_incr_ms;
    }
    else if(!old_mia.is_mia)   { // Previously not MIA, but it is MIA now
        // Copy MIA struct, then re-write the MIA counter and is_mia that is overwriten
        *msg = BRIDGE_TOTAL_CHECKPOINT__MIA_MSG;
        msg->mia_info.mia_counter_ms = BRIDGE_TOTAL_CHECKPOINT__MIA_MS;
        msg->mia_info.is_mia = true;
        mia_occurred = true;
    }

    return mia_occurred;
}

/// Handle the MIA for GEO's COMPASS_DATA message
/// @param   time_incr_ms  The time to increment the MIA counter with
/// @returns true if the MIA just occurred
/// @post    If the MIA counter reaches the MIA threshold, MIA struct will be copied to *msg
static inline bool dbc_handle_mia_COMPASS_DATA(COMPASS_DATA_t *msg, uint32_t time_incr_ms)
{
    bool mia_occurred = false;
    const dbc_mia_info_t old_mia = msg->mia_info;
    msg->mia_info.is_mia = (msg->mia_info.mia_counter_ms >= COMPASS_DATA__MIA_MS);

    if (!msg->mia_info.is_mia) { // Not MIA yet, so keep incrementing the MIA counter
        msg->mia_info.mia_counter_ms += time_incr_ms;
    }
    else if(!old_mia.is_mia)   { // Previously not MIA, but it is MIA now
        // Copy MIA struct, then re-write the MIA counter and is_mia that is overwriten
        *msg = COMPASS_DATA__MIA_MSG;
        msg->mia_info.mia_counter_ms = COMPASS_DATA__MIA_MS;
        msg->mia_info.is_mia = true;
        mia_occurred = true;
    }

    return mia_occurred;
}

/// Handle the MIA for GEO's GPS_LOCATION message
/// @param   time_incr_ms  The time to increment the MIA counter with
/// @returns true if the MIA just occurred
/// @post    If the MIA counter reaches the MIA threshold, MIA struct will be copied to *msg
static inline bool dbc_handle_mia_GPS_LOCATION(GPS_LOCATION_t *msg, uint32_t time_incr_ms)
{
    bool mia_occurred = false;
    const dbc_mia_info_t old_mia = msg->mia_info;
    msg->mia_info.is_mia = (msg->mia_info.mia_counter_ms >= GPS_LOCATION__MIA_MS);

    if (!msg->mia_info.is_mia) { // Not MIA yet, so keep incrementing the MIA counter
        msg->mia_info.mia_counter_ms += time_incr_ms;
    }
    else if(!old_mia.is_mia)   { // Previously not MIA, but it is MIA now
        // Copy MIA struct, then re-write the MIA counter and is_mia that is overwriten
        *msg = GPS_LOCATION__MIA_MSG;
        msg->mia_info.mia_counter_ms = GPS_LOCATION__MIA_MS;
        msg->mia_info.is_mia = true;
        mia_occurred = true;
    }

    return mia_occurred;
}

#endif
